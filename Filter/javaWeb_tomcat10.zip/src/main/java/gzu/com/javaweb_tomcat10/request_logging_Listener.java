package gzu.com.javaweb_tomcat10;

import jakarta.servlet.ServletRequestEvent;
import jakarta.servlet.ServletRequestListener;
import jakarta.servlet.annotation.WebListener;
import jakarta.servlet.http.HttpServletRequest;

import java.util.logging.Logger;

@WebListener
public class request_logging_Listener implements ServletRequestListener{
    private static final Logger logger = Logger.getLogger(request_logging_Listener.class.getName());

    @Override
    public void requestInitialized(ServletRequestEvent sre) {
        HttpServletRequest request = (HttpServletRequest) sre.getServletRequest();

        // 获取请求详细信息
        String ipAddress = request.getRemoteAddr();
        String method = request.getMethod();
        String uri = request.getRequestURI();
        String queryString = request.getQueryString() != null ? request.getQueryString() : "";
        String userAgent = request.getHeader("User-Agent");

        // 记录开始时间
        long startTime = System.currentTimeMillis();
        request.setAttribute("startTime", startTime);

        // 日志记录开始请求
        logger.info(String.format(
                "Request started:%n" +  // 换行
                        "IP=%s%n" +             // 换行
                        "Method=%s%n" +          // 换行
                        "URI=%s%n" +             // 换行
                        "Query=%s%n" +           // 换行
                        "User-Agent=%s%n" +      // 换行
                        "Time=%d",
                ipAddress, method, uri, queryString, userAgent, startTime
        ));
    }

    @Override
    public void requestDestroyed(ServletRequestEvent sre) {
        HttpServletRequest request = (HttpServletRequest) sre.getServletRequest();

        // 获取开始时间
        long startTime = (long) request.getAttribute("startTime");
        long endTime = System.currentTimeMillis();
        long processingTime = endTime - startTime;

        // 日志记录请求结束
        logger.info(String.format("Request ended: Processing Time=%d ms", processingTime));
    }
}
