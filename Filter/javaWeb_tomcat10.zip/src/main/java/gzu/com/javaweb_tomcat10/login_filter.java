package gzu.com.javaweb_tomcat10;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

@WebFilter("/*")
public class login_filter implements Filter {
    // 定义不需要过滤的路径列表
    private static final List<String> EXCLUDED_PATHS = Arrays.asList("/login.jsp", "/loginServlet");

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // 初始化过滤器
    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) servletRequest;
        HttpServletResponse response = (HttpServletResponse) servletResponse;

        String requestURI = request.getRequestURI();

        // 检查用户的 session 是否包含 "user" 属性，表明用户已登录
        HttpSession session = request.getSession(false);

        // 检查请求路径是否在排除列表中
        if (isExcludedPath(requestURI)) {
            // 如果请求路径在排除列表中，允许请求通过
            filterChain.doFilter(request, response);
            return;
        }

        if (session != null && session.getAttribute("user") != null) {
            // 用户已登录，允许请求通过
            filterChain.doFilter(request, response);
        } else {
            // 用户未登录，重定向到登录页面
            response.sendRedirect(request.getContextPath() + "/login.jsp");
        }
    }

    // 方法：检查当前请求路径是否在排除列表中
    private boolean isExcludedPath(String requestURI) {
        return EXCLUDED_PATHS.stream().anyMatch(requestURI::endsWith);
    }
}
