# 《 第四次作业：SQL练习》



> 学院：省级示范性软件学院
> 课程：Java Web后端开发技术
> 题目：《第四次作业：SQL练习》
> 姓名：李穗杰
> 学号：1977000019
> 班级：软工2201
> 日期：2024-10-18
> 实验环境： MySQL8、Navicat16
> 实验目的：熟练掌握SQL查询语句的运用
> 实验内容：根据给出的题目使用SQL查询语句得到答案

## 前期准备

### 将老师准备好的数据导入employee_management数据库

```
-- 创建数据库
CREATE DATABASE IF NOT EXISTS employee_management;
USE employee_management;

-- 创建部门表
CREATE TABLE departments (
    dept_id INT PRIMARY KEY AUTO_INCREMENT,
    dept_name VARCHAR(50) NOT NULL,
    location VARCHAR(50)
);

-- 创建员工表
CREATE TABLE employees (
    emp_id INT PRIMARY KEY AUTO_INCREMENT,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) UNIQUE,
    phone_number VARCHAR(20),
    hire_date DATE,
    job_title VARCHAR(50),
    salary DECIMAL(10, 2),
    dept_id INT,
    FOREIGN KEY (dept_id) REFERENCES departments(dept_id)
);

-- 创建项目表
CREATE TABLE projects (
    project_id INT PRIMARY KEY AUTO_INCREMENT,
    project_name VARCHAR(100) NOT NULL,
    start_date DATE,
    end_date DATE
);

-- 创建员工项目关联表
CREATE TABLE employee_projects (
    emp_id INT,
    project_id INT,
    PRIMARY KEY (emp_id, project_id),
    FOREIGN KEY (emp_id) REFERENCES employees(emp_id),
    FOREIGN KEY (project_id) REFERENCES projects(project_id)
);

-- 插入部门数据
INSERT INTO departments (dept_name, location) VALUES
('HR', 'New York'),
('IT', 'San Francisco'),
('Finance', 'Chicago'),
('Marketing', 'Los Angeles'),
('Operations', 'Houston');

-- 插入员工数据
INSERT INTO employees (first_name, last_name, email, phone_number, hire_date, job_title, salary, dept_id) VALUES
('John', 'Doe', 'john.doe@example.com', '1234567890', '2020-01-15', 'HR Manager', 75000.00, 1),
('Jane', 'Smith', 'jane.smith@example.com', '2345678901', '2019-05-20', 'Software Engineer', 85000.00, 2),
('Mike', 'Johnson', 'mike.johnson@example.com', '3456789012', '2018-11-10', 'Financial Analyst', 70000.00, 3),
('Emily', 'Brown', 'emily.brown@example.com', '4567890123', '2021-03-01', 'Marketing Specialist', 65000.00, 4),
('David', 'Wilson', 'david.wilson@example.com', '5678901234', '2017-09-15', 'Operations Manager', 80000.00, 5),
('Sarah', 'Lee', 'sarah.lee@example.com', '6789012345', '2020-07-01', 'IT Support', 60000.00, 2),
('Chris', 'Anderson', 'chris.anderson@example.com', '7890123456', '2019-12-01', 'Accountant', 68000.00, 3),
('Lisa', 'Taylor', 'lisa.taylor@example.com', '8901234567', '2022-01-10', 'HR Assistant', 55000.00, 1),
('Tom', 'Martin', 'tom.martin@example.com', '9012345678', '2018-06-15', 'Software Developer', 82000.00, 2),
('Amy', 'White', 'amy.white@example.com', '0123456789', '2021-09-01', 'Marketing Manager', 78000.00, 4);

-- 插入项目数据
INSERT INTO projects (project_name, start_date, end_date) VALUES
('Website Redesign', '2023-01-01', '2024-11-30'),
('ERP Implementation', '2023-03-15', '2025-03-14'),
('Marketing Campaign', '2023-05-01', '2023-08-31'),
('Financial Audit', '2023-07-01', '2025-09-30'),
('New Product Launch', '2023-09-01', '2024-02-29');

-- 插入员工项目关联数据
INSERT INTO employee_projects (emp_id, project_id) VALUES
(2, 1), (6, 1), (9, 1),
(2, 2), (5, 2), (6, 2), (9, 2),
(4, 3), (10, 3),
(3, 4), (7, 4),
(4, 5), (5, 5), (10, 5);
```

### 将老师准备好的数据导入test40数据库

```
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for course
-- ----------------------------
DROP TABLE IF EXISTS `course`;
CREATE TABLE `course`  (
  `course_id` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `course_name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `teacher_id` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `credits` decimal(2, 1) NULL DEFAULT NULL,
  PRIMARY KEY (`course_id`) USING BTREE,
  INDEX `teacher_id`(`teacher_id`) USING BTREE,
  CONSTRAINT `course_ibfk_1` FOREIGN KEY (`teacher_id`) REFERENCES `teacher` (`teacher_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of course
-- ----------------------------
INSERT INTO `course` VALUES ('C001', '高等数学', 'T001', 4.0);
INSERT INTO `course` VALUES ('C002', '大学物理', 'T002', 3.5);
INSERT INTO `course` VALUES ('C003', '程序设计', 'T003', 4.0);
INSERT INTO `course` VALUES ('C004', '数据结构', 'T004', 3.5);
INSERT INTO `course` VALUES ('C005', '数据库原理', 'T005', 4.0);
INSERT INTO `course` VALUES ('C006', '操作系统', 'T006', 3.5);

-- ----------------------------
-- Table structure for score
-- ----------------------------
DROP TABLE IF EXISTS `score`;
CREATE TABLE `score`  (
  `student_id` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `course_id` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `score` decimal(4, 1) NULL DEFAULT NULL,
  PRIMARY KEY (`student_id`, `course_id`) USING BTREE,
  INDEX `course_id`(`course_id`) USING BTREE,
  CONSTRAINT `score_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `student` (`student_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `score_ibfk_2` FOREIGN KEY (`course_id`) REFERENCES `course` (`course_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of score
-- ----------------------------
INSERT INTO `score` VALUES ('2021001', 'C001', 85.5);
INSERT INTO `score` VALUES ('2021001', 'C002', 78.0);
INSERT INTO `score` VALUES ('2021001', 'C003', 90.5);
INSERT INTO `score` VALUES ('2021002', 'C001', 92.0);
INSERT INTO `score` VALUES ('2021002', 'C002', 83.5);
INSERT INTO `score` VALUES ('2021002', 'C004', 58.0);
INSERT INTO `score` VALUES ('2021003', 'C001', 76.5);
INSERT INTO `score` VALUES ('2021003', 'C003', 85.0);
INSERT INTO `score` VALUES ('2021003', 'C005', 69.5);
INSERT INTO `score` VALUES ('2021004', 'C002', 88.5);
INSERT INTO `score` VALUES ('2021004', 'C004', 92.5);
INSERT INTO `score` VALUES ('2021004', 'C006', 86.0);
INSERT INTO `score` VALUES ('2021005', 'C001', 61.0);
INSERT INTO `score` VALUES ('2021005', 'C003', 87.5);
INSERT INTO `score` VALUES ('2021005', 'C005', 84.0);
INSERT INTO `score` VALUES ('2021006', 'C002', 79.5);
INSERT INTO `score` VALUES ('2021006', 'C004', 83.0);
INSERT INTO `score` VALUES ('2021006', 'C006', 90.0);
INSERT INTO `score` VALUES ('2021007', 'C001', 93.5);
INSERT INTO `score` VALUES ('2021007', 'C003', 89.0);
INSERT INTO `score` VALUES ('2021007', 'C005', 94.5);
INSERT INTO `score` VALUES ('2021008', 'C002', 86.5);
INSERT INTO `score` VALUES ('2021008', 'C004', 91.0);
INSERT INTO `score` VALUES ('2021008', 'C006', 87.5);
INSERT INTO `score` VALUES ('2021009', 'C001', 80.0);
INSERT INTO `score` VALUES ('2021009', 'C003', 62.5);
INSERT INTO `score` VALUES ('2021009', 'C005', 85.5);
INSERT INTO `score` VALUES ('2021010', 'C002', 64.5);
INSERT INTO `score` VALUES ('2021010', 'C004', 89.5);
INSERT INTO `score` VALUES ('2021010', 'C006', 93.0);

-- ----------------------------
-- Table structure for student
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student`  (
  `student_id` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `gender` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `birth_date` date NULL DEFAULT NULL,
  `my_class` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  PRIMARY KEY (`student_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO `student` VALUES ('2021001', '张三', '男', '2003-05-15', '计算机一班');
INSERT INTO `student` VALUES ('2021002', '李四', '女', '2003-08-22', '计算机一班');
INSERT INTO `student` VALUES ('2021003', '王五', '男', '2002-11-30', '数学一班');
INSERT INTO `student` VALUES ('2021004', '赵六', '女', '2003-02-14', '数学一班');
INSERT INTO `student` VALUES ('2021005', '钱七', '男', '2002-07-08', '物理一班');
INSERT INTO `student` VALUES ('2021006', '孙八', '女', '2003-09-19', '物理一班');
INSERT INTO `student` VALUES ('2021007', '周九', '男', '2002-12-01', '化学一班');
INSERT INTO `student` VALUES ('2021008', '吴十', '女', '2003-03-25', '化学一班');
INSERT INTO `student` VALUES ('2021009', '郑十一', '男', '2002-06-11', '生物一班');
INSERT INTO `student` VALUES ('2021010', '王十二', '女', '2003-10-05', '生物一班');

-- ----------------------------
-- Table structure for teacher
-- ----------------------------
DROP TABLE IF EXISTS `teacher`;
CREATE TABLE `teacher`  (
  `teacher_id` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `gender` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `birth_date` date NULL DEFAULT NULL,
  `title` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  PRIMARY KEY (`teacher_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of teacher
-- ----------------------------
INSERT INTO `teacher` VALUES ('T001', '张教授', '男', '1975-03-12', '教授');
INSERT INTO `teacher` VALUES ('T002', '李副教授', '女', '1980-07-22', '副教授');
INSERT INTO `teacher` VALUES ('T003', '王讲师', '男', '1985-11-08', '讲师');
INSERT INTO `teacher` VALUES ('T004', '赵助教', '女', '1990-05-15', '助教');
INSERT INTO `teacher` VALUES ('T005', '钱教授', '男', '1972-09-30', '教授');
INSERT INTO `teacher` VALUES ('T006', '孙副教授', '女', '1978-12-18', '副教授');
INSERT INTO `teacher` VALUES ('T007', '周讲师', '男', '1983-04-25', '讲师');
INSERT INTO `teacher` VALUES ('T008', '吴助教', '女', '1988-08-07', '助教');
INSERT INTO `teacher` VALUES ('T009', '郑教授', '男', '1970-01-01', '教授');
INSERT INTO `teacher` VALUES ('T010', '刘副教授', '女', '1976-06-14', '副教授');

SET FOREIGN_KEY_CHECKS = 1;

```



## 作业内容--员工部分

### 1.查询所有员工的姓名、邮箱和工作岗位。

```
-- 1. 查询所有员工的姓名、邮箱和工作岗位。
SELECT CONCAT(first_name,' ',last_name),email,job_title
FROM employees;
```

### 2.查询所有部门的名称和位置。

```
-- 2. 查询所有部门的名称和位置。
SELECT dept_name,location
FROM departments;
```

3.查询工资超过70000的员工姓名和工资。

```
-- 3. 查询工资超过70000的员工姓名和工资。
SELECT CONCAT(first_name,' ',last_name) , salary
FROM employees
WHERE salary > 70000;
```

### 4.查询IT部门的所有员工。

```
-- 4. 查询IT部门的所有员工。
SELECT CONCAT(first_name,' ',last_name) , job_title
FROM employees
WHERE dept_id = (SELECT dept_id FROM departments WHERE dept_name = 'IT');
```

### 5.查询入职日期在2020年之后的员工信息。

```
-- 5. 查询入职日期在2020年之后的员工信息。
SELECT *
FROM employees
WHERE hire_date > '2020-01-01';
```

### 6. 计算每个部门的平均工资。

```
-- 6. 计算每个部门的平均工资。
SELECT d.dept_name, AVG(e.salary) AS average_salary
FROM employees e
JOIN departments d ON e.dept_id = d.dept_id
GROUP BY d.dept_name;
```

### 7. 查询工资最高的前3名员工信息。

```
-- 7. 查询工资最高的前3名员工信息。
SELECT *
FROM employees
ORDER BY salary DESC
LIMIT 3;
```

### 8. 查询每个部门员工数量。

```
-- 8. 查询每个部门员工数量。
SELECT d.dept_name, COUNT(e.emp_id) AS employee_count
FROM departments d
LEFT JOIN employees e ON d.dept_id = e.dept_id
GROUP BY d.dept_name;
```

### 9. 查询没有分配部门的员工。

```
-- 9. 查询没有分配部门的员工。
SELECT CONCAT(first_name,' ',last_name)
FROM employees
WHERE dept_id IS NULL;
```

### 10. 查询参与项目数量最多的员工。

```
-- 10. 查询参与项目数量最多的员工。
SELECT CONCAT(e.first_name,' ',e.last_name), COUNT(ep.project_id) AS project_count
FROM employees e
LEFT JOIN employee_projects ep ON e.emp_id = ep.emp_id
GROUP BY e.emp_id
ORDER BY project_count DESC
LIMIT 1;
```

### 11.计算所有员工的工资总和。

```
-- 11. 计算所有员工的工资总和。
SELECT SUM(salary) AS total_salary
FROM employees;
```

### 12. 查询姓"Smith"的员工信息。

```
-- 12. 查询姓"Smith"的员工信息。
SELECT *
FROM employees
WHERE last_name = 'Smith';
```

### 13. 查询即将在半年内到期的项目。

```
-- 13. 查询即将在半年内到期的项目。
SELECT *
FROM projects
WHERE end_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 6 MONTH);
```

### 14. 查询至少参与了两个项目的员工。

```
-- 14. 查询至少参与了两个项目的员工。
SELECT CONCAT(e.first_name,' ', e.last_name), COUNT(ep.project_id) AS project_count
FROM employees e
JOIN employee_projects ep ON e.emp_id = ep.emp_id
GROUP BY e.emp_id
HAVING project_count >= 2;
```

### 15. 查询没有参与任何项目的员工。

```
-- 15. 查询没有参与任何项目的员工。
SELECT CONCAT(e.first_name,' ', e.last_name)AS e_name
FROM employees e
LEFT JOIN employee_projects ep ON e.emp_id = ep.emp_id
WHERE ep.project_id IS NULL;
```

### 16. 计算每个项目参与的员工数量。

```
-- 16. 计算每个项目参与的员工数量。
SELECT p.project_name, COUNT(ep.emp_id) AS employee_count
FROM projects p
LEFT JOIN employee_projects ep ON p.project_id = ep.project_id
GROUP BY p.project_name;
```

### 17. 查询工资第二高的员工信息。

```
-- 17. 查询工资第二高的员工信息。
SELECT *
FROM employees
ORDER BY salary DESC
LIMIT 1 OFFSET 1;
```

### 18. 查询每个部门工资最高的员工。

```
-- 18. 查询每个部门工资最高的员工。
SELECT e.first_name, e.last_name, e.salary, d.dept_name
FROM employees e
JOIN departments d ON e.dept_id = d.dept_id
WHERE (e.salary, e.dept_id) IN (
    SELECT MAX(salary), dept_id
    FROM employees
    GROUP BY dept_id
);
```

### 19. 计算每个部门的工资总和,并按照工资总和降序排列。

```
-- 19. 计算每个部门的工资总和,并按照工资总和降序排列。
SELECT d.dept_name, SUM(e.salary) AS total_salary
FROM departments d
LEFT JOIN employees e ON d.dept_id = e.dept_id
GROUP BY d.dept_name
ORDER BY total_salary DESC;
```

### 20. 查询员工姓名、部门名称和工资。

```
-- 20. 查询员工姓名、部门名称和工资。
SELECT CONCAT(e.first_name,' ', e.last_name), d.dept_name, e.salary
FROM employees e
JOIN departments d ON e.dept_id = d.dept_id;
```

### 21. 查询每个员工的上级主管(假设emp_id小的是上级)。

```
-- 21. 查询每个员工的上级主管(假设emp_id小的是上级)。
SELECT e1.first_name AS employee_name, e2.first_name AS supervisor_name
FROM employees e1
LEFT JOIN employees e2 ON e1.dept_id = e2.dept_id AND e1.emp_id > e2.emp_id;
```

### 22. 查询所有员工的工作岗位,不要重复。

```
-- 22. 查询所有员工的工作岗位,不要重复。
SELECT DISTINCT job_title
FROM employees;
```

### 23. 查询平均工资最高的部门。

```
-- 23. 查询平均工资最高的部门。
SELECT d.dept_name, AVG(e.salary) AS average_salary
FROM departments d
JOIN employees e ON d.dept_id = e.dept_id
GROUP BY d.dept_name
ORDER BY average_salary DESC
LIMIT 1;
```

### 24. 查询工资高于其所在部门平均工资的员工。

```
-- 24. 查询工资高于其所在部门平均工资的员工。
SELECT e.first_name, e.last_name, e.salary, d.dept_name
FROM employees e
JOIN departments d ON e.dept_id = d.dept_id
WHERE e.salary > (
    SELECT AVG(salary)
    FROM employees
    WHERE dept_id = e.dept_id
);
```

### 25. 查询每个部门工资前两名的员工。

```
-- 25. 查询每个部门工资前两名的员工。
SELECT first_name, last_name, salary, dept_name
FROM (
    SELECT e.first_name, e.last_name, e.salary, d.dept_name,
           RANK() OVER (PARTITION BY e.dept_id ORDER BY e.salary DESC) AS `rank`
    FROM employees e
    JOIN departments d ON e.dept_id = d.dept_id
) AS RankedSalaries
WHERE `rank` <= 2;
```

### 26. 查询跨部门的项目(参与员工来自不同部门)。

```
-- 26. 查询跨部门的项目(参与员工来自不同部门)。
SELECT p.project_name, ep.project_id, COUNT(DISTINCT e.dept_id) AS department_count
FROM employee_projects ep
JOIN employees e ON ep.emp_id = e.emp_id
JOIN projects p ON ep.project_id = p.project_id
GROUP BY ep.project_id, p.project_name
HAVING department_count > 1;
```

### 27. 查询每个员工的工作年限,并按工作年限降序排序。

```
-- 27. 查询每个员工的工作年限,并按工作年限降序排序。
SELECT first_name, last_name, FLOOR(DATEDIFF(CURDATE(), hire_date) / 365) AS years_of_service
FROM employees
ORDER BY years_of_service DESC;
```

### 28. 查询本月过生日的员工(假设hire_date是生日)。

```
-- 28. 查询本月过生日的员工(假设hire_date是生日)。
SELECT first_name, last_name, hire_date
FROM employees
WHERE MONTH(hire_date) = MONTH(CURDATE());
```

### 29. 查询即将在90天内到期的项目和负责该项目的员工。

```
-- 29. 查询即将在90天内到期的项目和负责该项目的员工。
SELECT p.project_name, e.first_name, e.last_name, p.end_date
FROM projects p
JOIN employee_projects ep ON p.project_id = ep.project_id
JOIN employees e ON ep.emp_id = e.emp_id
WHERE DATEDIFF(p.end_date, CURDATE()) <= 90;
```

### 30. 计算每个项目的持续时间(天数)。

```
-- 30. 计算每个项目的持续时间(天数)。
SELECT project_name, DATEDIFF(end_date, start_date) AS project_duration
FROM projects;
```

### 31. 查询没有进行中项目的部门。

```
-- 31. 查询没有进行中项目的部门。
SELECT d.dept_name
FROM departments d
LEFT JOIN employees e ON d.dept_id = e.dept_id
LEFT JOIN employee_projects ep ON e.emp_id = ep.emp_id
WHERE ep.project_id IS NULL;
```

### 32. 查询员工数量最多的部门。

```
-- 32. 查询员工数量最多的部门。
SELECT d.dept_name, COUNT(e.emp_id) AS employee_count
FROM departments d
JOIN employees e ON d.dept_id = e.dept_id
GROUP BY d.dept_name
ORDER BY employee_count DESC
LIMIT 1;
```

### 33. 查询参与项目最多的部门。

```
-- 33. 查询参与项目最多的部门。
SELECT d.dept_name, COUNT(DISTINCT ep.project_id) AS project_count
FROM departments d
JOIN employees e ON d.dept_id = e.dept_id
JOIN employee_projects ep ON e.emp_id = ep.emp_id
GROUP BY d.dept_name
ORDER BY project_count DESC
LIMIT 1;
```

### 34. 计算每个员工的薪资涨幅(假设每年涨5%)。

```
-- 34. 计算每个员工的薪资涨幅(假设每年涨5%)。
SELECT first_name, last_name, salary,salary * POWER(1.05, FLOOR(DATEDIFF(CURDATE(), hire_date) / 365)) AS increased_salary
FROM employees;
```

### 35. 查询入职时间最长的3名员工。

```
-- 35. 查询入职时间最长的3名员工。
SELECT first_name, last_name, hire_date
FROM employees
ORDER BY hire_date
LIMIT 3;
```

### 36. 查询名字和姓氏相同的员工。

```
-- 36. 查询名字和姓氏相同的员工。
SELECT first_name, last_name
FROM employees
WHERE first_name = last_name;
```

### 37. 查询每个部门薪资最低的员工。

```
-- 37. 查询每个部门薪资最低的员工。
SELECT e.first_name, e.last_name, e.salary, d.dept_name
FROM employees e
JOIN departments d ON e.dept_id = d.dept_id
WHERE e.salary = (
    SELECT MIN(salary)
    FROM employees
    WHERE dept_id = e.dept_id
);
```

### 38. 查询哪些部门的平均工资高于公司的平均工资。

```
-- 38. 查询哪些部门的平均工资高于公司的平均工资。
SELECT d.dept_name, AVG(e.salary) AS department_avg_salary
FROM departments d
JOIN employees e ON d.dept_id = e.dept_id
GROUP BY d.dept_name
HAVING department_avg_salary > (SELECT AVG(salary) FROM employees);
```

### 39. 查询姓名包含"son"的员工信息。

```
-- 39. 查询姓名包含"son"的员工信息。
SELECT *
FROM employees
WHERE first_name LIKE '%son%' OR last_name LIKE '%son%';
```

### 40. 查询所有员工的工资级别(可以自定义工资级别)。

```
-- 40. 查询所有员工的工资级别(可以自定义工资级别)。
SELECT first_name, last_name, salary,
       CASE
           WHEN salary < 50000 THEN 'Low'
           WHEN salary BETWEEN 50000 AND 80000 THEN 'Medium'
           ELSE 'High'
       END AS salary_level
FROM employees;
```

## 作业内容--学生部分

### 1. 查询所有学生的信息。

```
-- 1. 查询所有学生的信息。
SELECT * FROM student;
```

### 2. 查询所有课程的信息

```
-- 2. 查询所有课程的信息
SELECT * FROM course;
```

### 3. 查询所有学生的姓名、学号和班级

```
-- 3. 查询所有学生的姓名、学号和班级
SELECT student_id, name, my_class FROM student;
```

### 4. 查询所有教师的姓名和职称

```
-- 4. 查询所有教师的姓名和职称
SELECT name, title FROM teacher;
```

### 5. 查询不同课程的平均分数

```
-- 5. 查询不同课程的平均分数
SELECT course_id, AVG(score) AS average_score FROM score GROUP BY course_id;
```

### 6. 查询每个学生的平均分数

```
-- 6. 查询每个学生的平均分数
SELECT student_id, AVG(score) AS average_score FROM score GROUP BY student_id;
```

### 7. 查询分数大于85分的学生学号和课程号

```
-- 7. 查询分数大于85分的学生学号和课程号
SELECT student_id, course_id FROM score WHERE score > 85;
```

### 8. 查询每门课程的选课人数

```
-- 8. 查询每门课程的选课人数
SELECT course_id, COUNT(student_id) AS student_count FROM score GROUP BY course_id;
```

### 9. 查询选修了"高等数学"课程的学生姓名和分数

```
-- 9. 查询选修了"高等数学"课程的学生姓名和分数
SELECT s.name, sc.score 
FROM student s 
JOIN score sc ON s.student_id = sc.student_id
JOIN course c ON sc.course_id = c.course_id
WHERE c.name = '高等数学';
```

### 10. 查询没有选修"大学物理"课程的学生姓名

```
-- 10. 查询没有选修"大学物理"课程的学生姓名
SELECT s.name 
FROM student s
WHERE NOT EXISTS (
    SELECT 1
    FROM score sc
    JOIN course c ON sc.course_id = c.course_id
    WHERE s.student_id = sc.student_id AND c.name = '大学物理'
);
```

### 11. 查询C001比C002课程成绩高的学生信息及课程分数

```
-- 11. 查询C001比C002课程成绩高的学生信息及课程分数
SELECT s.student_id, s.name, sc1.score AS C001_score, sc2.score AS C002_score
FROM student s
JOIN score sc1 ON s.student_id = sc1.student_id AND sc1.course_id = 'C001'
JOIN score sc2 ON s.student_id = sc2.student_id AND sc2.course_id = 'C002'
WHERE sc1.score > sc2.score;
```

### 12. 统计各科成绩各分数段人数：课程编号，课程名称，[100-85]，[85-70]，[70-60]，[60-0] 及所占百分比

```
-- 12. 统计各科成绩各分数段人数：课程编号，课程名称，[100-85]，[85-70]，[70-60]，[60-0] 及所占百分比
SELECT c.course_id, c.course_name,
       SUM(CASE WHEN sc.score BETWEEN 85 AND 100 THEN 1 ELSE 0 END) AS "100-85",
       SUM(CASE WHEN sc.score BETWEEN 70 AND 85 THEN 1 ELSE 0 END) AS "85-70",
       SUM(CASE WHEN sc.score BETWEEN 60 AND 70 THEN 1 ELSE 0 END) AS "70-60",
       SUM(CASE WHEN sc.score < 60 THEN 1 ELSE 0 END) AS "60-0",
       ROUND(SUM(CASE WHEN sc.score BETWEEN 85 AND 100 THEN 1 ELSE 0 END) / COUNT(*) * 100, 2) AS "100-85_percent"
FROM course c
JOIN score sc ON c.course_id = sc.course_id
GROUP BY c.course_id, c.course_name;
```

### 13. 查询选择C002课程但没选择C004课程的成绩情况(不存在时显示为 null )

```
-- 13. 查询选择C002课程但没选择C004课程的成绩情况(不存在时显示为 null )
SELECT s.student_id, s.name, sc2.score AS C002_score, sc4.score AS C004_score
FROM student s
LEFT JOIN score sc2 ON s.student_id = sc2.student_id AND sc2.course_id = 'C002'
LEFT JOIN score sc4 ON s.student_id = sc4.student_id AND sc4.course_id = 'C004'
WHERE sc2.score IS NOT NULL AND sc4.score IS NULL;
```

### 14. 查询平均分数最高的学生姓名和平均分数

```
-- 14. 查询平均分数最高的学生姓名和平均分数
SELECT s.name, AVG(sc.score) AS avg_score
FROM student s
JOIN score sc ON s.student_id = sc.student_id
GROUP BY s.student_id
ORDER BY avg_score DESC
LIMIT 1;
```

### 15. 查询总分最高的前三名学生的姓名和总分

```
-- 15. 查询总分最高的前三名学生的姓名和总分
SELECT s.name, SUM(sc.score) AS total_score
FROM student s
JOIN score sc ON s.student_id = sc.student_id
GROUP BY s.student_id
ORDER BY total_score DESC
LIMIT 3;
```

### 16. 查询各科成绩最高分、最低分和平均分，并统计各分数段的比例。以如下形式显示：课程 ID，课程 name，最高分，最低分，平均分，及格率，中等率，优良率，优秀率。及格为>=60，中等为：70-80，优良为：80-90，优秀为：>=90。要求输出课程号和选修人数，查询结果按人数降序排列，若人数相同，按课程号升序排列

```
-- 16. 查询各科成绩最高分、最低分和平均分，并统计各分数段的比例
-- 以如下形式显示：课程 ID，课程 name，最高分，最低分，平均分，及格率，中等率，优良率，优秀率
-- 及格为>=60，中等为：70-80，优良为：80-90，优秀为：>=90
-- 要求输出课程号和选修人数，查询结果按人数降序排列，若人数相同，按课程号升序排列
SELECT c.course_id, c.course_name,
       MAX(sc.score) AS highest_score,
       MIN(sc.score) AS lowest_score,
       AVG(sc.score) AS average_score,
       SUM(CASE WHEN sc.score >= 60 THEN 1 ELSE 0 END) / COUNT(*) * 100 AS pass_rate,
       SUM(CASE WHEN sc.score BETWEEN 70 AND 80 THEN 1 ELSE 0 END) / COUNT(*) * 100 AS middle_rate,
       SUM(CASE WHEN sc.score BETWEEN 80 AND 90 THEN 1 ELSE 0 END) / COUNT(*) * 100 AS good_rate,
       SUM(CASE WHEN sc.score >= 90 THEN 1 ELSE 0 END) / COUNT(*) * 100 AS excellent_rate,
       COUNT(sc.student_id) AS student_count
FROM course c
JOIN score sc ON c.course_id = sc.course_id
GROUP BY c.course_id
ORDER BY student_count DESC, c.course_id ASC;
```

### 17. 查询男生和女生的人数

```
-- 17. 查询男生和女生的人数
SELECT gender, COUNT(*) AS count
FROM student
GROUP BY gender;
```

### 18. 查询年龄最大的学生姓名

```
-- 18. 查询年龄最大的学生姓名
SELECT name
FROM student
ORDER BY birth_date ASC
LIMIT 1;
```

### 19. 查询年龄最小的教师姓名

```
-- 19. 查询年龄最小的教师姓名
SELECT name
FROM teacher
ORDER BY birth_date DESC
LIMIT 1;
```

### 20. 查询学过「张教授」授课的同学的信息

```
-- 20. 查询学过「张教授」授课的同学的信息
SELECT DISTINCT s.student_id, s.name, s.gender, s.birth_date, s.my_class
FROM student s
JOIN score sc ON s.student_id = sc.student_id
JOIN course c ON sc.course_id = c.course_id
WHERE c.teacher_id = (
    SELECT teacher_id
    FROM teacher
    WHERE name = '张教授'
);
```

### 21. 查询至少有一门课与学号为"2021001"的同学所学相同的同学的信息。

```
-- 21. 查询至少有一门课与学号为"2021001"的同学所学相同的同学的信息。
SELECT DISTINCT s2.student_id, s2.name, s2.gender, s2.birth_date, s2.my_class
FROM student s2
JOIN score sc2 ON s2.student_id = sc2.student_id
WHERE sc2.course_id IN (
    SELECT course_id
    FROM score
    WHERE student_id = '2021001'
) AND s2.student_id <> '2021001';
```

### 22. 查询每门课程的平均分数，并按平均分数降序排列。

```
-- 22. 查询每门课程的平均分数，并按平均分数降序排列。
SELECT c.course_name, AVG(sc.score) AS average_score
FROM course c
JOIN score sc ON c.course_id = sc.course_id
GROUP BY c.course_name
ORDER BY average_score DESC;
```

### 23. 查询学号为"2021001"的学生所有课程的分数。

```
-- 23. 查询学号为"2021001"的学生所有课程的分数。
SELECT c.course_name, sc.score
FROM score sc
JOIN course c ON sc.course_id = c.course_id
WHERE sc.student_id = '2021001';
```

### 24. 查询所有学生的姓名、选修的课程名称和分数。

```
-- 24. 查询所有学生的姓名、选修的课程名称和分数。
SELECT s.name, c.course_name, sc.score
FROM student s
JOIN score sc ON s.student_id = sc.student_id
JOIN course c ON sc.course_id = c.course_id;
```

### 25. 查询每个教师所教授课程的平均分数。

```
-- 25. 查询每个教师所教授课程的平均分数。
SELECT t.name AS teacher_name, AVG(sc.score) AS average_score
FROM teacher t
JOIN course c ON t.teacher_id = c.teacher_id
JOIN score sc ON c.course_id = sc.course_id
GROUP BY t.name;
```

### 26. 查询分数在80到90之间的学生姓名和课程名称。

```
-- 26. 查询分数在80到90之间的学生姓名和课程名称。
SELECT s.name, c.course_name
FROM score sc
JOIN student s ON sc.student_id = s.student_id
JOIN course c ON sc.course_id = c.course_id
WHERE sc.score BETWEEN 80 AND 90;
```

### 27. 查询每个班级的平均分数。

```
-- 27. 查询每个班级的平均分数。
SELECT s.my_class, AVG(sc.score) AS average_score
FROM student s
JOIN score sc ON s.student_id = sc.student_id
GROUP BY s.my_class;
```

### 28. 查询没学过"王讲师"老师讲授的任一门课程的学生姓名。

```
-- 28. 查询没学过"王讲师"老师讲授的任一门课程的学生姓名。
SELECT s.name
FROM student s
WHERE s.student_id NOT IN (
    SELECT sc.student_id
    FROM score sc
    JOIN course c ON sc.course_id = c.course_id
    JOIN teacher t ON c.teacher_id = t.teacher_id
    WHERE t.name = '王讲师'
);
```

### 29. 查询两门及其以上小于85分的同学的学号，姓名及其平均成绩。

```
-- 29. 查询两门及其以上小于85分的同学的学号，姓名及其平均成绩。
SELECT s.student_id, s.name, AVG(sc.score) AS average_score
FROM student s
JOIN score sc ON s.student_id = sc.student_id
WHERE sc.score < 85
GROUP BY s.student_id, s.name
HAVING COUNT(*) >= 2;
```

### 30. 查询所有学生的总分并按降序排列。

```
-- 30. 查询所有学生的总分并按降序排列。
SELECT s.student_id, s.name, SUM(sc.score) AS total_score
FROM student s
JOIN score sc ON s.student_id = sc.student_id
GROUP BY s.student_id, s.name
ORDER BY total_score DESC;
```

### 31. 查询平均分数超过85分的课程名称。

```
-- 31. 查询平均分数超过85分的课程名称。
SELECT c.course_name
FROM course c
JOIN score sc ON c.course_id = sc.course_id
GROUP BY c.course_name
HAVING AVG(sc.score) > 85;
```

### 32. 查询每个学生的平均成绩排名。

```
-- 32. 查询每个学生的平均成绩排名。
SELECT s.student_id, s.name, AVG(sc.score) AS average_score,RANK() OVER (ORDER BY AVG(sc.score) DESC) AS ranking
FROM student s
JOIN score sc ON s.student_id = sc.student_id
GROUP BY s.student_id, s.name;
```

### 33. 查询每门课程分数最高的学生姓名和分数。

```
-- 33. 查询每门课程分数最高的学生姓名和分数。
SELECT c.course_name, s.name, sc.score
FROM score sc
JOIN course c ON sc.course_id = c.course_id
JOIN student s ON sc.student_id = s.student_id
WHERE (c.course_id, sc.score) IN (
    SELECT course_id, MAX(score)
    FROM score
    GROUP BY course_id
);
```

### 34. 查询选修了"高等数学"和"大学物理"的学生姓名。

```
-- 34. 查询选修了"高等数学"和"大学物理"的学生姓名。
SELECT s.name
FROM student s
WHERE s.student_id IN (
    SELECT sc.student_id
    FROM score sc
    JOIN course c ON sc.course_id = c.course_id
    WHERE c.course_name IN ('高等数学', '大学物理')
    GROUP BY sc.student_id
    HAVING COUNT(DISTINCT c.course_name) = 2
);
```

### 35. 按平均成绩从高到低显示所有学生的所有课程的成绩以及平均成绩（没有选课则为空）。

```
-- 35. 按平均成绩从高到低显示所有学生的所有课程的成绩以及平均成绩（没有选课则为空）。
SELECT s.student_id, s.name, c.course_name, sc.score,
       AVG(sc.score) OVER (PARTITION BY s.student_id) AS average_score
FROM student s
LEFT JOIN score sc ON s.student_id = sc.student_id
LEFT JOIN course c ON sc.course_id = c.course_id
ORDER BY average_score DESC;
```

### 36. 查询分数最高和最低的学生姓名及其分数。

```
-- 36. 查询分数最高和最低的学生姓名及其分数。
SELECT name, score
FROM score sc
JOIN student s ON sc.student_id = s.student_id
WHERE score = (SELECT MAX(score) FROM score)
   OR score = (SELECT MIN(score) FROM score);
```

### 37. 查询每个班级的最高分和最低分。

```
-- 37. 查询每个班级的最高分和最低分。
SELECT s.my_class, MAX(sc.score) AS highest_score, MIN(sc.score) AS lowest_score
FROM student s
JOIN score sc ON s.student_id = sc.student_id
GROUP BY s.my_class;
```

### 38. 查询每门课程的优秀率（优秀为90分）。

```
-- 38. 查询每门课程的优秀率（优秀为90分）。
SELECT c.course_name,SUM(CASE WHEN sc.score >= 90 THEN 1 ELSE 0 END) * 100.0 / COUNT(sc.student_id) AS excellence_rate
FROM course c
JOIN score sc ON c.course_id = sc.course_id
GROUP BY c.course_name;
```

### 39. 查询平均分数超过班级平均分数的学生。

```
-- 39. 查询平均分数超过班级平均分数的学生。
SELECT s.student_id, s.name
FROM student s
JOIN score sc ON s.student_id = sc.student_id
GROUP BY s.student_id, s.name
HAVING AVG(sc.score) > (
    SELECT AVG(sc_inner.score)
    FROM score sc_inner
    JOIN student s_inner ON sc_inner.student_id = s_inner.student_id
    WHERE s_inner.my_class = (
        SELECT my_class
        FROM student
        WHERE student_id = s.student_id
    )
);
```

### 40. 查询每个学生的分数及其与课程平均分的差值。

```
-- 40. 查询每个学生的分数及其与课程平均分的差值。
SELECT s.student_id, s.name, sc.course_id, sc.score, 
       (sc.score - (SELECT AVG(score) FROM score WHERE course_id = sc.course_id)) AS score_difference
FROM student s
JOIN score sc ON s.student_id = sc.student_id;
```

### 41. 查询至少有一门课程分数低于80分的学生姓名。

```
-- 41. 查询至少有一门课程分数低于80分的学生姓名。
SELECT DISTINCT s.name
FROM student s
JOIN score sc ON s.student_id = sc.student_id
WHERE sc.score < 80;
```

### 42. 查询所有课程分数都高于85分的学生姓名。

```
-- 42. 查询所有课程分数都高于85分的学生姓名。
SELECT s.name
FROM student s
WHERE NOT EXISTS (
    SELECT 1 
    FROM score sc 
    WHERE sc.student_id = s.student_id 
    AND sc.score <= 85
);
```

### 43. 查询平均成绩大于等于90分的同学的学生编号和学生姓名和平均成绩。

```
-- 43. 查询平均成绩大于等于90分的同学的学生编号和学生姓名和平均成绩。
SELECT s.student_id, s.name, AVG(sc.score) AS average_score
FROM student s
JOIN score sc ON s.student_id = sc.student_id
GROUP BY s.student_id, s.name
HAVING AVG(sc.score) >= 90;
```

### 44. 查询选修课程数量最少的学生姓名。

```
-- 44. 查询选修课程数量最少的学生姓名。
SELECT s.name
FROM student s
JOIN score sc ON s.student_id = sc.student_id
GROUP BY s.student_id, s.name
ORDER BY COUNT(sc.course_id) ASC
LIMIT 1;
```

### 48. 查询每个学生的总分和他所在班级的平均分数。

```
-- 48. 查询每个学生的总分和他所在班级的平均分数。
SELECT s.student_id, s.name, SUM(sc.score) AS total_score,
       (SELECT AVG(score) FROM score sc2 
        JOIN student s2 ON sc2.student_id = s2.student_id 
        WHERE s2.my_class = s.my_class) AS class_average_score
FROM student s
JOIN score sc ON s.student_id = sc.student_id
GROUP BY s.student_id, s.name;
```

### 49. 查询每个学生的最高分的课程名称, 学生名称，成绩。

```
-- 49. 查询每个学生的最高分的课程名称, 学生名称，成绩。
SELECT s.name, c.course_name, MAX(sc.score) AS highest_score
FROM student s
JOIN score sc ON s.student_id = sc.student_id
JOIN course c ON sc.course_id = c.course_id
GROUP BY s.student_id, c.course_name
HAVING MAX(sc.score) IN (
    SELECT MAX(score) 
    FROM score sc2 
    WHERE sc2.student_id = s.student_id
);
```

### 50. 查询每个班级的学生人数和平均年龄。

```
-- 50. 查询每个班级的学生人数和平均年龄。
SELECT my_class, COUNT(*) AS student_count, AVG(TIMESTAMPDIFF(YEAR, birth_date, CURDATE())) AS average_age
FROM student
GROUP BY my_class;
```

