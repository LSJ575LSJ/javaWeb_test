package gzu.com.jdbc_test;

import java.sql.*;

public class Scroll_insensitive {
    private static final String URL = "jdbc:mysql://localhost:3306/Teacher"; // 修改为你的数据库名
    private static final String USER = "root"; // 数据库用户名
    private static final String PASSWORD = "123456"; // 数据库密码
    private static final String sql = "SELECT * FROM teacher WHERE id > 400";

    public static void main(String[] args) {

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement ps = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
        ) {
            // 执行查询
            try (ResultSet rs = ps.executeQuery()) {
                // 移动到最后一行
                rs.last();
                // 向前移动2行
                rs.relative(-2);
                System.out.println(rs.getInt("id") + " " + rs.getString("name"));
            }catch (SQLException e) {
                e.printStackTrace();
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
