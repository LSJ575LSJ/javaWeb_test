package gzu.com.jdbc_test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Create_DBTeacher_and_TTeacher {
    private static final String URL = "jdbc:mysql://localhost:3306/";
    private static final String USER = "root"; // 数据库用户名
    private static final String PASSWORD = "123456"; // 数据库密码

    public static void main(String[] args) {
        Connection connection = null;
        Statement statement = null;

        try {
            // 连接数据库
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
            // 创建 Statement
            statement = connection.createStatement();

            // 创建数据库的 SQL 语句
            String createDatabaseSQL = "CREATE DATABASE IF NOT EXISTS Teacher;";
            statement.executeUpdate(createDatabaseSQL);
            System.out.println("数据库 'Teacher' 创建成功！");

            // 切换到新创建的数据库
            String useDatabaseSQL = "USE Teacher;";
            statement.executeUpdate(useDatabaseSQL);

            // 创建表的 SQL 语句
            String createTableSQL = "CREATE TABLE `teacher` (" +
                    "`id` int NOT NULL COMMENT 'id', " +
                    "`name` varchar(255) DEFAULT NULL COMMENT '姓名', " +
                    "`course` varchar(255) DEFAULT NULL COMMENT '课程', " +
                    "`birthday` date DEFAULT NULL COMMENT '生日', " +
                    "PRIMARY KEY (`id`)" +
                    ");";

            // 执行 SQL 语句
            statement.executeUpdate(createTableSQL);
            System.out.println("表 'teacher' 创建成功！");

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // 关闭资源
            try {
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
