package gzu.com.jdbc_test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Teacher_CRUD_test {
    private static final String URL = "jdbc:mysql://localhost:3306/Teacher"; // 修改为你的数据库名
    private static final String USER = "root"; // 数据库用户名
    private static final String PASSWORD = "123456"; // 数据库密码

    public static void main(String[] args) {
        // 示例调用
        insertTeacher(1, "张三", "数学", "2000-01-01");
        updateTeacher(1, "李四", "物理", "1999-12-31");
        queryTeachers();
        deleteTeacher(1);
    }

    // 插入数据
    public static void insertTeacher(int id, String name, String course, String birthday) {
        String sql = "INSERT INTO teacher (id, name, course, birthday) VALUES (?, ?, ?, ?)";
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            statement.setString(2, name);
            statement.setString(3, course);
            statement.setDate(4, java.sql.Date.valueOf(birthday));
            statement.executeUpdate();
            System.out.println("教师信息插入成功！");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 更新数据
    public static void updateTeacher(int id, String name, String course, String birthday) {
        String sql = "UPDATE teacher SET name = ?, course = ?, birthday = ? WHERE id = ?";
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, name);
            statement.setString(2, course);
            statement.setDate(3, java.sql.Date.valueOf(birthday));
            statement.setInt(4, id);
            statement.executeUpdate();
            System.out.println("教师信息更新成功！");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 查询数据
    public static void queryTeachers() {
        String sql = "SELECT * FROM teacher";
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                String course = resultSet.getString("course");
                String birthday = resultSet.getDate("birthday").toString();
                System.out.println("ID: " + id + ", 姓名: " + name + ", 课程: " + course + ", 生日: " + birthday);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 删除数据
    public static void deleteTeacher(int id) {
        String sql = "DELETE FROM teacher WHERE id = ?";
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            statement.executeUpdate();
            System.out.println("教师信息删除成功！");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

