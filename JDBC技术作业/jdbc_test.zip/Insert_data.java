package gzu.com.jdbc_test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

public class Insert_data {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/Teacher";
        String user = "root"; // 数据库用户名
        String password = "123456"; // 数据库密码
        // 批量插入数据
        String sql = "INSERT INTO teacher(id, name, course, birthday) VALUES(?, ?, ?, ?)";

        Set<String> uniqueNames = generateUniqueNames(500);
        try (Connection conn = DriverManager.getConnection(url, user, password)) {
            conn.setAutoCommit(false);
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                Random random = new Random();
                int index = 1;

                // 设置参数
                for (String name : uniqueNames) {
                    String course = "课程" + (random.nextInt(10) + 1); // 随机生成课程
                    String birthday = generateRandomBirthday(random); // 随机生成生日

                    ps.setInt(1, index++); // id
                    ps.setString(2, name); // name
                    ps.setString(3, course); // course
                    ps.setString(4, birthday); // birthday

                    // 添加到批处理
                    ps.addBatch();

                    if (index % 100 == 0) { // 每100条记录执行一次批处理
                        ps.executeBatch();
                        conn.commit(); // 提交事务
                        ps.clearBatch();
                    }
                }
                ps.executeBatch(); // 执行剩余的批处理
                conn.commit(); // 提交事务
                System.out.println("完成批量插入数据");
            } catch (SQLException e) {
                conn.rollback();
                e.printStackTrace();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static Set<String> generateUniqueNames(int count) {
        Set<String> names = new HashSet<>();
        Random random = new Random();
        String[] firstNames = {"张", "李", "王", "赵", "钱", "孙", "周", "吴", "郑", "冯"};
        String[] secondNames = {"伟", "芳", "敏", "静", "杰", "丽", "洋", "强", "磊", "婷"};
        String[] thirdNames = {"明", "华", "丽", "刚", "军", "健", "飞", "娜", "婷", "磊"};

        while (names.size() < count) {
            String firstName = firstNames[random.nextInt(firstNames.length)];
            String secondName = secondNames[random.nextInt(secondNames.length)];
            String thirdName = thirdNames[random.nextInt(thirdNames.length)];
            String fullName = firstName + secondName + thirdName; // 生成三字名字
            names.add(fullName);
        }

        return names;
    }

    private static String generateRandomBirthday(Random random) {
        int year = 1970 + random.nextInt(50); // 随机年份 1970-2020
        int month = 1 + random.nextInt(12); // 随机月份 1-12
        int day = 1 + random.nextInt(28); // 随机日期 1-28
        return String.format("%04d-%02d-%02d", year, month, day); // 格式化为 yyyy-MM-dd
    }
}
