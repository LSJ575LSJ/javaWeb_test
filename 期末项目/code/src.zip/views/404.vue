<template>
  <div>
    <div style="height: 100vh; display: flex; justify-content: center; align-items: center">
      <div style="width: 30%">
        <img src="@/assets/imgs/404.jpg" alt="" style="width: 100%">
        <div style="font-size: 30px; text-align: center">找不到页面啦！<router-link to="/">请返回主页</router-link></div>
      </div>
    </div>
  </div>
</template>