<template>
  <div>
    <div class="front-notice"><el-icon><Bell /></el-icon>公告：{{ data.top }}</div>
    <div class="front-header">
      <div class="front-header-left">
        <img src="@/assets/imgs/logo.png" alt="">
        <a href="/front/home"><div class="title">图书借阅系统</div></a>
      </div>
      <div class="front-header-center">
        <el-menu :default-active="router.currentRoute.value.path" router mode="horizontal">
          <el-menu-item index="/front/home">首页</el-menu-item>
          <el-menu-item index="/front/book">图书馆</el-menu-item>
        </el-menu>
      </div>

      <div class="front-header-right" style="flex: 1; display: flex; justify-content: space-between; align-items: center;">
        <div style="width: 350px">
          <el-input clearable style="width: 240px; margin-right: 10px" v-model="data.name" placeholder="请输入图书名称搜索"></el-input>
          <el-button @click="goPage('/front/book?name=' + data.name)" type="primary">搜索</el-button>
        </div>
        <div v-if="!data.user.id">
          <el-button @click="router.push('/login')">登录</el-button>
          <el-button @click="router.push('/register')">注册</el-button>
        </div>
        <div v-else>
          <el-dropdown style="cursor: pointer; height: 60px">
            <div style="display: flex; align-items: center">
              <img style="width: 40px; height: 40px; border-radius: 50%;" :src="data.user.avatar" alt="">
              <span style="margin-left: 5px; color: #333">{{ data.user.name }}</span><el-icon><arrow-down /></el-icon>
            </div>
            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item @click="goPage('/front/cart')">我的书单</el-dropdown-item>
                <el-dropdown-item @click="goPage('/front/orders')">我的借书</el-dropdown-item>
                <el-dropdown-item @click="goPage('/front/person')">个人信息</el-dropdown-item>
                <el-dropdown-item @click="goPage('/front/password')">修改密码</el-dropdown-item>
                <el-dropdown-item @click="logout">退出登录</el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
        </div>
      </div>
    </div>
    <div class="main-body">
      <RouterView @updateUser="updateUser" />
    </div>

    <Footer />
  </div>
</template>

<script setup>
  import router from "@/router/index.js";
  import { reactive,computed } from "vue";
  import request from "@/utils/request.js";
  import Footer from "@/compoents/Foorter.vue"


  const data = reactive({
    user: JSON.parse(localStorage.getItem('xm-user') || '{}'),
    top: '',
    noticeData: [],
    name: null,
    queryType: 'name', // 搜索框初始查询类型
    value: '', // 搜索框输入框的值
  })

  // 使用 computed 创建计算属性
  const queryPlaceholder = computed(() => {
    // 根据选择的查询类型返回不同的占位符
    if (data.queryType === 'name') {
      return '图书名称';
    } else if (data.queryType === 'author') {
      return '作者';
    } else if (data.queryType === 'isbn') {
      return 'ISBN';
    }
    return ''; // 默认返回空字符串
  });

  const goPage = (path) => {
    location.href = path
  }

  const logout = () => {
    localStorage.removeItem('xm-user')
    router.push('/login')
  }

  const updateUser = () => {
    data.user =  JSON.parse(localStorage.getItem('xm-user') || '{}')
  }

  const loadNotice = () => {
    request.get('/notice/selectAll').then(res => {
      data.noticeData = res.data
      let i = 0
      if (data.noticeData && data.noticeData.length) {
        data.top = data.noticeData[0].content
        setInterval(() => {
          data.top = data.noticeData[i].content
          i++
          if (i === data.noticeData.length) {
            i = 0
          }
        }, 2500)
      }
    })
  }
  loadNotice()
</script>

<style scoped>
@import "@/assets/css/front.css";
</style>