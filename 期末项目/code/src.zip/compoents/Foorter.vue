<template>
  <div style="padding: 20px 0; background-color: #333">
    <div style="width: 60%; margin: 10px auto; text-align: center; font-size: 12px; color: #ddd; ">
      <div style="margin-bottom: 10px">2024 图书借阅系统. All Rights Reserved</div>
      <div style="margin-bottom: 10px">ICP证123456号 <span style="margin: 0 10px">|</span> 出版物经营许可证 新出发京批字第直575号 <span style="margin: 0 10px">|</span> 经营许可证：GZU66668888</div>
      <div style="margin-bottom: 10px">ICP备12345号-1 <span style="margin: 0 10px">|</span> 网安备 8888899999号京公网安备11010502037644号 <span style="margin: 0 10px">|</span> 经营许可证编号：合字123456 <span style="margin: 0 10px">|</span> 互联网信息服务资格证</div>
      <div style="margin-bottom: 10px">互联网违法和不良信息举报电话：400666888，涉未成年举报电话：40066666666，邮箱：2956437585@qq.com</div>
      <div style="margin-bottom: 10px"><a style="color: #ddd" href="javaxmsz.cn" target="_blank">图书借阅系统</a> 通信地址：贵州省贵阳市花溪区贵州大学</div>
    </div>
  </div>
</template>