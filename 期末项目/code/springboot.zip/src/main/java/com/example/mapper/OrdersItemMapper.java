package com.example.mapper;

import com.example.entity.OrdersItem;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface OrdersItemMapper {

    int insert(OrdersItem ordersItem);

    void updateById(OrdersItem ordersItem);

    void deleteById(Integer id);

    @Select("select * from `orders_Item` where id = #{id}")
    OrdersItem selectById(Integer id);

    List<OrdersItem> selectAll(OrdersItem ordersItem);

    @Select("select * from `orders_Item` where order_id = #{orderId}")
    List<OrdersItem> selectByOrederId(Integer orderId);
}
