package com.example.common.enums;

public enum RoleEnum {
    // 管理员
    ADMIN,
    USER
}
