package com.example.entity;

/**
 * 订单明细
 */
public class OrdersItem {
    /** ID */
    private Integer id;
    /** 图书ID */
    private Integer bookId;
    /** 图书名称 */
    private String bookName;
    /** 图书封面 */
    private String bookCover;
    /** 数量 */
    private Integer num;
    /** 借书订单ID */
    private Integer orderId;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getBookId() {
        return bookId;
    }

    public void setBookId(Integer bookId) {
        this.bookId = bookId;
    }

    public String getBookName() {
        return bookName;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }

    public String getBookCover() {
        return bookCover;
    }

    public void setBookCover(String bookCover) {
        this.bookCover = bookCover;
    }

    public Integer getNum() {
        return num;
    }

    public void setNum(Integer num) {
        this.num = num;
    }

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }
}
